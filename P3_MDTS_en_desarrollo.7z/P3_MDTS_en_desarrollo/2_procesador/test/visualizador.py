import os
import xarray as xr
import matplotlib.pyplot as plt
import numpy as np

def normalize_channel(channel):
    """Normaliza un canal RGB al rango [0, 1]."""
    channel_min = np.nanmin(channel)
    channel_max = np.nanmax(channel)
    return (channel - channel_min) / (channel_max - channel_min)

def visualize_rgb(rgb_file, output_image):
    """Visualiza un archivo RGB y guarda la imagen como PNG."""
    ds = xr.open_dataset(rgb_file)

    if not all(channel in ds.variables for channel in ['Red', 'Green', 'Blue']):
        print("El archivo RGB no contiene todos los canales necesarios.")
        return

    # Normalizar canales
    red = normalize_channel(ds['Red'].values)
    green = normalize_channel(ds['Green'].values)
    blue = normalize_channel(ds['Blue'].values)

    # Crear imagen RGB
    rgb_image = np.dstack((red, green, blue))

    # Visualizar y guardar la imagen
    plt.imshow(rgb_image)
    plt.axis('off')
    plt.title(f"Visualización de {os.path.basename(rgb_file)}")
    plt.savefig(output_image, bbox_inches='tight')
    plt.show()
    print(f"Imagen RGB guardada en: {output_image}")

def get_latest_folder(base_path):
    """Obtiene la carpeta más reciente en el directorio base."""
    folders = [os.path.join(base_path, d) for d in os.listdir(base_path) if os.path.isdir(os.path.join(base_path, d))]
    if not folders:
        return None
    return max(folders, key=os.path.getmtime)

def main():
    base_path = './2_procesador/data/'
    latest_folder = get_latest_folder(base_path)

    if not latest_folder:
        print("No se encontraron carpetas en el directorio especificado.")
        return

    rgb_file = os.path.join(latest_folder, f"{os.path.basename(latest_folder)}_rgb_result.nc")
    output_image = os.path.join(latest_folder, f"{os.path.basename(latest_folder)}_rgb_image.png")

    if not os.path.exists(rgb_file):
        print(f"El archivo RGB especificado no existe: {rgb_file}")
        return

    visualize_rgb(rgb_file, output_image)

if __name__ == "__main__":
    main()
