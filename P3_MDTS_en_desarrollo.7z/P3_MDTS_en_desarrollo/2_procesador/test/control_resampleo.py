import os
import xarray as xr
import numpy as np

def get_latest_folder(base_path):
    """Obtiene la carpeta más reciente en el directorio base."""
    folders = [os.path.join(base_path, d) for d in os.listdir(base_path) if os.path.isdir(os.path.join(base_path, d))]
    if not folders:
        return None
    return max(folders, key=os.path.getmtime)

def verify_band_dimensions(resampled_dir):
    """Verifica que todas las bandas en el directorio resampleado tengan las mismas dimensiones."""
    dimensions = None
    for file in os.listdir(resampled_dir):
        if file.endswith('.nc'):
            file_path = os.path.join(resampled_dir, file)
            ds = xr.open_dataset(file_path)
            if dimensions is None:
                dimensions = ds.dims
            elif ds.dims != dimensions:
                print(f"Dimensiones no coinciden en {file}: {ds.dims} != {dimensions}")
                return False
    print("Todas las bandas tienen dimensiones consistentes.")
    return True

def verify_planck_constants(resampled_dir):
    """Verifica que las constantes de Planck estén presentes en las bandas térmicas."""
    thermal_bands = ['07', '08', '10', '13']
    for file in os.listdir(resampled_dir):
        if any(f"M6C{band}" in file for band in thermal_bands):
            file_path = os.path.join(resampled_dir, file)
            ds = xr.open_dataset(file_path)
            for const in ['planck_fk1', 'planck_fk2', 'planck_bc1', 'planck_bc2']:
                if const not in ds.variables:
                    print(f"Constante de Planck faltante en {file}: {const}")
                    return False
    print("Todas las constantes de Planck están presentes en las bandas térmicas.")
    return True

def verify_rgb_data(rgb_file):
    """Verifica que el archivo RGB tenga datos válidos."""
    ds = xr.open_dataset(rgb_file)
    for channel in ['Red', 'Green', 'Blue']:
        if channel not in ds.variables:
            print(f"Canal faltante en el archivo RGB: {channel}")
            return False
        data = ds[channel].values
        if np.isnan(data).all():
            print(f"El canal {channel} contiene solo valores NaN.")
            return False
    print("El archivo RGB contiene datos válidos.")
    return True

def main():
    base_path = './2_procesador/data/'
    latest_folder = get_latest_folder(base_path)

    if not latest_folder:
        print("No se encontraron carpetas en el directorio especificado.")
        return

    resampled_dir = os.path.join(latest_folder, 'resampled')
    rgb_file = os.path.join(latest_folder, f"{os.path.basename(latest_folder)}_rgb_result.nc")

    print("\n=== Verificación de dimensiones ===")
    dimensions_ok = verify_band_dimensions(resampled_dir)

    print("\n=== Verificación de constantes de Planck ===")
    planck_ok = verify_planck_constants(resampled_dir)

    print("\n=== Verificación de archivo RGB ===")
    rgb_ok = verify_rgb_data(rgb_file)

    if dimensions_ok and planck_ok and rgb_ok:
        print("\nTodas las verificaciones se completaron con éxito. El resampleo y álgebra de bandas son correctos.")
    else:
        print("\nAlgunas verificaciones fallaron. Revise los mensajes de error anteriores.")

if __name__ == "__main__":
    main()

