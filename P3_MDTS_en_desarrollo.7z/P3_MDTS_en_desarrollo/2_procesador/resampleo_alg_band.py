import os
import xarray as xr
import json
import numpy as np

# Crear directorios si no existen
def create_directory(path):
    if not os.path.exists(path):
        os.makedirs(path)

# Leer configuración
def load_config(config_path):
    with open(config_path, 'r') as f:
        return json.load(f)

# Validar si la carpeta contiene todas las bandas requeridas
def is_folder_complete(folder_path, required_bands):
    """
    Verifica si una carpeta contiene todos los archivos de las bandas requeridas.
    """
    if not os.path.exists(folder_path):
        return False

    existing_files = os.listdir(folder_path)
    existing_bands = set(
        file.split('M6C')[-1].split('_')[0] for file in existing_files if 'M6C' in file
    )
    return all(band in existing_bands for band in required_bands)

# Encontrar el archivo de una banda específica
def find_band_file(folder_path, band):
    """
    Encuentra el archivo correspondiente a una banda específica en la carpeta.
    """
    for file in os.listdir(folder_path):
        if f"M6C{band}" in file:
            return os.path.join(folder_path, file)
    raise FileNotFoundError(f"No se encontró el archivo para la banda {band} en {folder_path}")

# Obtener referencia de la Banda 13
def get_reference_nc(ref_path):
    print(f"Obteniendo referencia de {ref_path}...")
    ds_ref = xr.open_dataset(ref_path)
    if 'x' not in ds_ref or 'y' not in ds_ref:
        raise ValueError(f"'x' o 'y' coordenadas no encontradas en {ref_path}")
    return ds_ref['x'].values, ds_ref['y'].values

# Copiar constantes de Planck
def copy_planck_constants(ds_in, ds_out):
    """Copia las constantes de Planck del dataset de entrada al de salida."""
    for const in ['planck_fk1', 'planck_fk2', 'planck_bc1', 'planck_bc2']:
        if const in ds_in.variables:
            ds_out[const] = ds_in[const]

# Convertir radiancia a temperatura de brillo
def radiance_to_brightness_temperature(radiance, ds):
    """Convierte radiancia a temperatura de brillo usando las constantes de Planck."""
    if all(var in ds.variables for var in ['planck_fk1', 'planck_fk2', 'planck_bc1', 'planck_bc2']):
        fk1 = ds['planck_fk1'].values
        fk2 = ds['planck_fk2'].values
        bc1 = ds['planck_bc1'].values
        bc2 = ds['planck_bc2'].values
        return (fk2 / (np.log((fk1 / radiance) + 1)) - bc1) / bc2 - 273.15
    else:
        raise ValueError("Constantes de Planck no disponibles en el dataset.")

# Normalizar bandas
def normalize_band(band):
    """Normaliza una banda al rango [0, 1]."""
    band_min = np.nanmin(band)
    band_max = np.nanmax(band)
    print(f"Normalizando banda: min={band_min}, max={band_max}")
    if band_max != band_min:
        return (band - band_min) / (band_max - band_min)
    else:
        return np.zeros_like(band)

# Resamplear banda
def resample_band(input_path, output_path, ref_x, ref_y, method='linear'):
    print(f"Resampleando {input_path}...")
    if not os.path.exists(input_path):
        print(f"Archivo {input_path} no encontrado. Omitiendo...")
        return

    try:
        ds = xr.open_dataset(input_path)
        if 'Rad' not in ds:
            print(f"'Rad' variable no encontrada en {input_path}. Omitiendo...")
            return

        # Interpolar la variable Rad
        resampled_data = ds['Rad'].interp(x=ref_x, y=ref_y, method=method)

        # Crear un nuevo dataset para guardar la banda resampleada
        ds_out = xr.Dataset({'Rad': resampled_data})
        
        # Copiar atributos importantes
        ds_out['Rad'].attrs = ds['Rad'].attrs
        copy_planck_constants(ds, ds_out)

        # Guardar archivo
        ds_out.to_netcdf(output_path)
        print(f"Banda resampleada guardada en: {output_path}")

    except Exception as e:
        print(f"Error al procesar {input_path}: {e}")

# Álgebra de bandas
def band_algebra(bands_data):
    """
    Aplica álgebra de bandas para generar los canales RGB.
    bands_data: diccionario con nombres de bandas como claves y datos como valores.
    """
    red = normalize_band(bands_data['08'] - bands_data['10'])
    green = normalize_band(bands_data['07'] - bands_data['13'])
    blue = normalize_band(bands_data['05'] - bands_data['02'])
    print(f"Álgebra de bandas: R={np.nanmean(red)}, G={np.nanmean(green)}, B={np.nanmean(blue)}")
    return red, green, blue

# Guardar resultado en NetCDF
def save_rgb_to_netcdf(red, green, blue, output_path, interval_name):
    """
    Guarda los canales RGB en un archivo NetCDF.
    """
    print(f"Guardando resultado RGB en: {output_path}")
    ds = xr.Dataset({
        'Red': (['y', 'x'], red),
        'Green': (['y', 'x'], green),
        'Blue': (['y', 'x'], blue)
    })
    # Añadir atributos del intervalo
    ds.attrs['interval_name'] = interval_name
    print(f"Atributo añadido: interval_name={interval_name}")
    ds.to_netcdf(output_path)
    print(f"Archivo RGB guardado exitosamente en: {output_path}")

# Procesar carpetas de intervalos
def process_intervals(input_base_dir, output_base_dir, config):
    bands = config['bands_list']
    reference_band = config['reference_band']
    method = config['resample_method']

    intervals = sorted(os.listdir(input_base_dir))
    for interval in intervals:
        interval_path = os.path.join(input_base_dir, interval)

        # Validar si la carpeta está completa
        if not is_folder_complete(interval_path, bands):
            print(f"Intervalo {interval} incompleto. Omitiendo...")
            continue

        resampled_dir = os.path.join(output_base_dir, interval, 'resampled')
        create_directory(resampled_dir)

        try:
            ref_path = find_band_file(interval_path, reference_band)
            ref_x, ref_y = get_reference_nc(ref_path)
        except Exception as e:
            print(f"Error al obtener referencia de {ref_path}: {e}")
            continue

        # Resamplear cada banda
        bands_data = {}
        for band in bands:
            try:
                input_band_path = find_band_file(interval_path, band)
                # Usar el nombre original del archivo para el archivo resampleado
                original_file_name = os.path.basename(input_band_path)
                output_band_path = os.path.join(resampled_dir, original_file_name)
                resample_band(input_band_path, output_band_path, ref_x, ref_y, method)

                # Almacenar bandas resampleadas en memoria para álgebra
                ds_resampled = xr.open_dataset(output_band_path)
                if band == '13':
                    bands_data[band] = radiance_to_brightness_temperature(ds_resampled['Rad'].values, ds_resampled)
                else:
                    bands_data[band] = ds_resampled['Rad'].values

                print(f"Banda {band}: min={np.nanmin(bands_data[band])}, max={np.nanmax(bands_data[band])}, mean={np.nanmean(bands_data[band])}")

            except FileNotFoundError as e:
                print(f"Error: {e}")
                continue

        # Aplicar álgebra de bandas después de resamplear
        try:
            red, green, blue = band_algebra(bands_data)
            rgb_output_path = os.path.join(output_base_dir, interval, f'{interval}_rgb_result.nc')
            save_rgb_to_netcdf(red, green, blue, rgb_output_path, interval)
        except Exception as e:
            print(f"Error al aplicar álgebra de bandas para {interval}: {e}")

   


    print("Proceso de resampleo completado.")

# Ejecución principal
if __name__ == "__main__":
    config_path = './2_procesador/config_resampleo.json'
    config = load_config(config_path)

    # Nuevas rutas de entrada y salida
    input_base_directory = './1_descarga/data'
    output_base_directory = './2_procesador/data'

    process_intervals(input_base_directory, output_base_directory, config)









