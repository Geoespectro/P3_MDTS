# Lógica de Resampleo y Álgebra de Bandas para Imágenes RGB

Esta lógica realiza un procesamiento automatizado de datos satelitales para generar imágenes RGB a partir de múltiples bandas espectrales. El flujo incluye resampleo, álgebra de bandas, validación y visualización de los resultados.

---

## **Estructura de Archivos**

- **`resampleo_alg_band.py`**: Contiene las funciones principales para resamplear las bandas, aplicar álgebra y guardar los resultados en archivos NetCDF.
- **`config_resampleo.json`**: Archivo de configuración con las bandas requeridas, banda de referencia y método de resampleo.
- **`control_resampleo.py`**: Script para verificar la calidad de los datos procesados.
- **`visualizador.py`**: Herramienta para visualizar y guardar las imágenes RGB generadas.

---

## **Flujo de la Lógica**

### **1. Configuración Inicial**

El archivo `config_resampleo.json` define:
- **`bands_list`**: Lista de bandas requeridas (`"02", "05", "07", "08", "10", "13"`).
- **`reference_band`**: Banda de referencia para el resampleo (por defecto, `"13"`).
- **`resample_method`**: Método de interpolación (por defecto, `"linear"`).

### **2. Resampleo y Álgebra de Bandas** (`resampleo_alg_band.py`)

#### **Principales funciones:**

1. **Resampleo**:
   - Ajusta las bandas a la rejilla espacial de la banda de referencia utilizando interpolación lineal.
   - Función principal: `resample_band(input_path, output_path, ref_x, ref_y, method)`.

2. **Álgebra de Bandas**:
   - Calcula los canales RGB combinando bandas espectrales:
     - **R (Rojo)**: Banda 08 - Banda 10.
     - **G (Verde)**: Banda 07 - Banda 13.
     - **B (Azul)**: Banda 05 - Banda 02.
   - Normaliza los resultados al rango `[0, 1]`.
   - Función principal: `band_algebra(bands_data)`.

3. **Guardar Resultados**:
   - Crea un archivo NetCDF con los canales `Red`, `Green` y `Blue`.
   - Función principal: `save_rgb_to_netcdf(red, green, blue, output_path, interval_name)`.

#### **Ejecución del procesamiento:**
```python
if __name__ == "__main__":
    config_path = './2_procesador/config_resampleo.json'
    config = load_config(config_path)
    input_base_directory = './1_descarga/data'
    output_base_directory = './2_procesador/data'
    process_intervals(input_base_directory, output_base_directory, config)
```

### **3. Validación de Datos** (`control_resampleo.py`)

Este script verifica la consistencia de los datos procesados:

- **Dimensiones Consistentes**:
  - Todas las bandas resampleadas deben tener las mismas dimensiones.
  - Función: `verify_band_dimensions(resampled_dir)`.

- **Constantes de Planck**:
  - Las bandas térmicas (`07`, `08`, `10`, `13`) deben incluir las constantes necesarias para convertir radiancia a temperatura de brillo.
  - Función: `verify_planck_constants(resampled_dir)`.

- **Datos RGB Válidos**:
  - El archivo RGB debe contener los canales `Red`, `Green` y `Blue` sin valores NaN.
  - Función: `verify_rgb_data(rgb_file)`.

#### **Ejecución del script:**
```python
if __name__ == "__main__":
    base_path = './2_procesador/data/'
    main()
```

### **4. Visualización** (`visualizador.py`)

Este script genera una visualización de los datos RGB procesados y los guarda como imágenes PNG.

#### **Principales funciones:**

- **Normalización de Canales**:
  ```python
  def normalize_channel(channel):
      return (channel - np.nanmin(channel)) / (np.nanmax(channel) - np.nanmin(channel))
  ```

- **Visualización y Guardado**:
  ```python
  def visualize_rgb(rgb_file, output_image):
      plt.imshow(rgb_image)
      plt.savefig(output_image)
      plt.show()
  ```

#### **Ejecución del script:**
```python
if __name__ == "__main__":
    base_path = './2_procesador/data/'
    main()
```

---

## **Instrucciones para la Ejecución**

1. **Configurar las rutas y parámetros**:
   - Asegúrate de que `config_resampleo.json` contenga las bandas requeridas y el método de resampleo deseado.

2. **Procesar las Bandas**:
   - Ejecuta `resampleo_alg_band.py` para realizar el resampleo y álgebra de bandas.

3. **Validar Resultados**:
   - Usa `control_resampleo.py` para verificar la calidad de los datos procesados.

4. **Visualizar los Resultados**:
   - Ejecuta `visualizador.py` para generar las imágenes PNG de los datos RGB.

---

## **Resultados Esperados**

- **NetCDF**: Archivos con canales RGB (`Red`, `Green`, `Blue`) almacenados en carpetas por intervalos.
- **Imágenes PNG**: Visualizaciones de los datos RGB guardadas en el mismo directorio que los archivos NetCDF.
- **Validación**: Mensajes que confirman la consistencia de las dimensiones, constantes de Planck y datos RGB.

---

## **Ejemplo de Configuración**

Archivo `config_resampleo.json`:
```json
{
    "bands_list": ["02", "05", "07", "08", "10", "13"],
    "reference_band": "13",
    "resample_method": "linear"
}
```

---








