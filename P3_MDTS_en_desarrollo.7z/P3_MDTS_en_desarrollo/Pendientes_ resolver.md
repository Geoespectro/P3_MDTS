Tareas Pendientes:

Implementar las funciones para recorte y reproyección.

Adaptar la lógica de generación del mapa final de los proyectos anteriores para mantener un diseño consistente entre los tres proyectos.

Validar los resultados contra datos históricos o modelos existentes.

Documentar y probar todas las funciones desarrolladas.

