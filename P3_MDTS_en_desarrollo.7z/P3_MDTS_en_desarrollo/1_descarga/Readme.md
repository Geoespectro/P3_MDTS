# Lógica de Descarga de Datos del GOES-16

Esta lógica automatiza la descarga de datos del satélite GOES-16 desde el repositorio S3 de NOAA, organizando los archivos en carpetas por intervalos de tiempo y bandas espectrales. Está diseñada para garantizar la integridad y consistencia de los datos descargados.

---

## **Estructura de Archivos**

- **`goes16Download.py`**: Script principal que gestiona el proceso de descarga.
- **`helpers.py`**: Funciones auxiliares para manejo de JSON, registro de logs y construcción de rutas remotas.
- **`setup.json`**: Archivo de configuración con parámetros clave como bandas, productos y tiempos.

---

## **Flujo de la Lógica**

### **1. Configuración Inicial**

El archivo `setup.json` define:
- **`product`**: Producto del GOES-16 a descargar (por defecto, `"ABI-L1b-RadF"`).
- **`bands`**: Lista de bandas espectrales requeridas (por defecto, `[2, 5, 7, 8, 10, 13]`).
- **`dates`**: Fecha inicial de descarga.
- **`start_hour`**: Hora de inicio.
- **`end_date` y `end_hour`**: Fecha y hora opcionales de fin.
- **`timeout`**: Tiempo de espera entre intentos de conexión fallidos (en segundos).
- **`max_workers`**: Número máximo de descargas concurrentes.

### **2. Descarga de Datos**

#### **Funciones Principales:**

1. **Conexión al Repositorio S3:**
   - Configura acceso anónimo al repositorio `s3://noaa-goes16/`.
   - Función: Uso de `s3fs` para listar y descargar archivos remotos.

2. **Gestión de Descargas:**
   - Los archivos se descargan en una carpeta temporal antes de ser movidos a su ubicación final.
   - Función principal: `download_file(f, temp_path, final_path, year, day, hour, minute)`.

3. **Organización de Archivos:**
   - Los datos se guardan en carpetas organizadas por intervalos (`YYYY-MM-DD_HHMM`).
   - Función auxiliar: `is_folder_complete(folder_path, required_bands)` valida si una carpeta contiene todas las bandas requeridas.

4. **Base de Datos Local:**
   - Uso de un archivo JSON (`download_db.json`) para rastrear el estado de las descargas y evitar redundancias.
   - Funciones:
     - `get_last_downloaded_time()`: Obtiene la última descarga registrada.
     - `writeJson()` y `readJson()`: Guardan y leen el estado de las descargas.

### **3. Validación de Carpetas**

- Después de descargar los archivos, se verifica que las carpetas contengan todas las bandas necesarias antes de pasar al siguiente intervalo.
- Las carpetas incompletas se reintentan hasta que el intervalo sea completado o se alcance el tiempo límite.

#### **Ejecución del script:**
```python
if __name__ == "__main__":
    while True:
        # Proceso principal de descarga
        ...
        if is_folder_complete(interval_path, bands):
            ...
        else:
            logger.warning(f'Carpeta incompleta para {current_datetime.strftime("%Y-%m-%d %H:%M")}. Reintentando...')
```

### **4. Manejo de Logs**

- Se registran todas las actividades y errores en un archivo de logs (`logs/YYYYMMDD_HHMMSS_logfile.log`).
- Función auxiliar: `createLogger(attachedFile, logPath)`.

---

## **Estructura del Directorio Después de la Ejecución**

```plaintext
1_descarga/
├── data/
│   ├── 2024-12-06_2300/
│   │   ├── OR_ABI-L1b-RadF-M6C02_G16_s20243402300207_e20243402309515_c20243402309561.nc
│   │   ├── OR_ABI-L1b-RadF-M6C05_G16_s20243402300207_e20243402309515_c20243402309569.nc
│   │   ├── ...
│   └── 2024-12-06_2310/
├── db/
│   └── download_db.json
├── logs/
│   └── YYYYMMDD_HHMMSS_logfile.log
├── temp/
│   └── Archivos temporales
└── setup.json
```

---

## **Instrucciones para la Ejecución**

1. **Configurar `setup.json`:**
   - Define las bandas, fechas y parámetros necesarios para la descarga.

2. **Ejecutar el Script:**
   ```bash
   python goes16Download.py
   ```

3. **Verificar Resultados:**
   - Las carpetas dentro de `data/` deben contener todas las bandas especificadas para cada intervalo.
   - Los logs detallan el progreso y cualquier error encontrado.

---

## **Notas Técnicas**

- **Requisitos:**
  - Python 3.8+.
  - Bibliotecas: `s3fs`, `json`, `datetime`, `concurrent.futures`.

- **Errores Comunes:**
  - **Fallo en la conexión S3:** Verifica la conexión a internet y el acceso al repositorio.
  - **Archivos incompletos:** Asegúrate de que la carpeta temporal tenga suficiente espacio y permisos de escritura.

---


